//store the value of my current age
const myAge

//store the value of 2
let earlyYears 
earlyYears *= 10.5;

//you finsih the rest!

//calculate years

//calc dog years
laterYears *= 4;
console.log(earlyYears);
console.log(laterYears);

//add years

//print to the console values stored in variables
